const config = {
    PORT: 3000
}

module.exports = config