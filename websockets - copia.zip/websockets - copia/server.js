const Koa = require('koa');
const serve = require('koa-static');
const http = require('http');
const socketIO = require('socket.io');
const config = require('./config');

const app = new Koa();
const server = http.createServer(app.callback());
const io = socketIO(server);

// Serve static files from the 'public' directory
app.use(serve('public'));

io.on('connection', (socket) => {
    console.log('New client connected');
    socket.emit('mensaje', 'Welcome!');

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

let contador = 1;
setInterval(() => {
    io.emit('mensaje', `Hello to all --> ${contador}`);
    contador++;
}, 5000);

server.listen(config.PORT, () => {
    console.log(`Server running at http://localhost:${config.PORT}`);
});

